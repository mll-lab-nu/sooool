# Asterix: adjudicated labels, minimal wrapper, and 5x readiness

The human-adjudicated round-2 labels remain frozen. The 18 core cases exclude C03a/C03b (unlabeled) and the execution-only diagnostics. Agreement is with the user's accepted action sets; it does not establish survival.

## Wrapper choice

User explicitly selected the minimal wrapper after unchanged-task randomized A/B. All subsequent calls use the entire game task, original images, original action format, low reasoning effort, and the existing sandbox. The installed CLI lacks `--ignore-user-config`, so a separate empty Codex home is used with existing subscription credentials mounted read-only, without copying them.

In 54 pairs, default/minimal mean complete-response latency was 7.98/7.87 seconds. Mean input tokens were 14,509/5,701; uncached input was approximately 2,349/1,757. The latency change is not significant and does not isolate a concurrency effect. Subscription token reductions are not equivalent to dollar savings.

## Candidate evidence

| Candidate and phase | Agreement | Forbidden head-on | C05b failures | Decision |
|---|---:|---:|---:|---|
| V6, minimal A/B arm | 46/54 = 85.2% | 0 | 0/3 | Screening only |
| V6, fresh confirmation | 71/90 = 78.9% | 2 | 1/5 | Reject |
| V7, minimal screening | 41/54 = 75.9% | 0 | 0/3 | Reject |
| V8, minimal screening | 42/54 = 77.8% | 0 | 0/3 | Reject |
| V9, minimal screening | 47/54 = 87.0% | 0 | 0/3 | Confirm |
| V9, fresh confirmation | 76/90 = 84.4% | 1 | 1/5 | Reject |
| V10, minimal screening | 47/54 = 87.0% | 1 | 0/3 | Reject |
| V11, minimal screening | 45/54 = 83.3% | 0 | 0/3 | Reject |

Acceptance requires >=85% (desired >=90%) in a fresh all-18-case, five-repeat confirmation, zero observed forbidden horizontal head-on outputs, and all C05b emergency escapes accepted. Zero observed failures is a sample result, not a guarantee. A new prompt is frozen before its confirmation; no labels are changed to match its answers.

## Execution fix and simulator

`HopControllerV2` prevents stale vertical replies from releasing an active hop prematurely. The original four-frame deadline does not extend. Explicit nonvertical commands can still release early. The historical paid controller and its logs remain unchanged.

For C06a, recorded replies produced UP only at frame 158 before stale UP became NOOP at 159. V2 holds UP through 161 and releases at 162. Replaying the same recorded answers gives original first life loss at frame 293 (2 lives at 300), versus 3 lives through 300 under V2. The answers after divergence came from old observations, so this is an execution diagnostic rather than new-policy survival evidence.

The new simulator uses 12 raw FPS (=60/5), observations every four raw frames, eight virtual workers per trajectory, and an aggregate maximum of eight native computations shared across independent trajectories. Native wall time is recorded separately and never substitutes for API latency. The empirical profile contains 596 existing 5x capture-to-complete measurements, mean 1.281 s and maximum 7.570 s; its original long tails remain in the IID samples. It measures the old policy, so the new prompt's API latency remains unknown.

Zero-model replay matches all frame rewards, lives, and issued image hashes for old seed 2 (1,186 frames; 297 requests; score 400) and seed 5 (1,194 frames; 299 requests; score 150). Five controller tests and four clock/scheduler tests pass locally and on the experiment server. Three real-ALE offline integration tests verify parallel episode logging, error preservation, and strict prefix extension without repeating model calls. These offline substitute-policy tests are code validation, not model performance evidence.

After a candidate passes confirmation: test closed-loop 5x trajectories on development seeds 2, 5, 6, then fresh repeats and 1.25x latency sensitivity. Unseen seeds 7, 8, 9 remain untouched. The earlier full-trajectory mean-score target remains 1,500; short-horizon scores are not compared to it. Every subscription dispatch checks the 50% stop line. No new paid API calls have been made. Realtime acceptance follows simulation, with a concrete paid-run budget before any new spending.

Same frozen strategy, empirical IID latency, development seeds 2/5/6, maximum 20 game seconds, minimal subscription wrapper. Seed 2: score 750, two lives at 20s. Seed 5: score 600, two lives at 20s. Seed 6: score 50, natural end at 14.833s. Mean score 466.7 over these short episodes. This is not acceptance against the full-trajectory 1,500 target. Historical actual API 5x seed 2/5 scores were 400/150 with both games ending before 20s; that comparison is contextual, not a controlled paired test of the prompt or executor.

Seed 6 reveals an asynchronous execution failure beyond snapshot direction choice. At observation 180 the player was on the bottom row; its LEFT answer arrived at frame 191, after an older UP answer started a row change at 184. LEFT then drove the player into an approaching lyre in the new row. At the next loss, an UPLEFT hop entered the row above and its left component continued after the hop, meeting that row's right-moving enemy before the next fresh escape arrived.

V3 makes row hops atomic for four frames, releases both components to NOOP on landing, and ignores the ENTIRE command if its observation predates hop completion. Ignored replies are logged separately from actual applied actions so the policy's action history does not falsely report ignored replies as new maneuvers. Pure horizontal commands from fresh observations still continue normally.

Zero-model branch diagnostics using prerecorded answers: branch at frame 184 preserved three lives through 344, versus original loss at 324; branch at 447 preserved two lives through 609, versus original second loss at 589. These diagnose execution mechanisms only: after divergence, the prerecorded answers were based on old observations. A new closed-loop V3 pilot is running.

Six V3 controller tests and a real-ALE V3 integration test pass. Tests verify stale horizontal rejection after a row change, full diagonal release, atomic hop duration, correct freshness boundary, and absence of ignored replies from the applied-action history.

All three trajectories survived 20 game seconds: seed 2 score 450/lives 3; seed 5 score 500/lives 2; seed 6 score 450/lives 2. Mean score remains 466.7, the same as V2's first pilot. Endpoint lives rose from 4 total to 7; score population standard deviation in these three observations is 23.6 versus 300.9. These are descriptive results of one stochastic batch, not an independently confirmed reliability improvement. V3 is the provisional stability candidate; full 60s runs, repeats, and latency sensitivity remain incomplete.

Simulator recovery now saves a contiguous completed-call prefix and matching earlier steps after quota/errors. A restart reuses completed prefix calls, rewinds only to the first missing observation, and verifies images/actions/delays before new inference. A real-ALE offline test verifies that four completed calls are reused after an injected stop and only six missing calls are newly executed. Full original stopped trajectories remain preserved.

## Full 60s validation and quota stop

The 1.25x response-delay scenario completed: seed 2 score 150/natural end at 14.8667s; seed 5 score 450/three lives at 20s; seed 6 score 400/two lives at 20s. Mean 333.3, two survivors. One stochastic batch per condition; it does not isolate a causal latency effect, and the new prompt's paid API latency remains unmeasured.

A new same-seed, same-latency-draw repeat was stopped by the native quota guard at 50%. Executed durations were 4.9667/4.5667/4.6333 game seconds. It is incomplete and cannot establish repeat reliability. The contiguous prefixes preserve 70/64/67 completed replies (201 total); no scores are extrapolated beyond the stop. All model processes finished and no further model requests were started. New paid API calls: zero.

A concrete pressure failure shows the next gap: seed 2 stalls at the left wall in the bottom row while a lyre approaches from the right. LEFT cannot create distance; RIGHT from observation 204 applies at 221 and meets the enemy. Collision animation is visible by 232 and the life count updates at 353. The earlier UPLEFT reply from observation 168 arrived at 193 but was superseded by a newer LEFT. V19 is prepared to escalate stalled boundary retreat into vertical escape, keep current-row safety above recentering, allow cleared crossings, and ensure landing-row safety until another fresh response can arrive. It has not been evaluated, and user labels remain unchanged.

The proposed next quota threshold is 55%, pending explicit user approval. A patch is prepared but not applied; actual default and server stop remain 50%. The next candidate's 54 screening and 90 confirmation tasks are prepared on the existing authorized server. No model calls above 50% have been made.

